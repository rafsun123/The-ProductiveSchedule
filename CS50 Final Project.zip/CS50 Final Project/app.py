import os
from cs50 import SQL
from flask import Flask, flash, redirect, render_template, request, session, url_for
from werkzeug.security import check_password_hash, generate_password_hash
from helpers import login_required
import datetime

db = SQL("sqlite:///database.db")
app = Flask(__name__)
app.secret_key = 'supersecretkey'



@app.route("/")
@login_required
def index():
    user_id = session["user_id"]
    todos = db.execute("SELECT * FROM todos WHERE user_id = ?", user_id)
    #False means the task is not completed; true means the task is completed in db.execute as it has boolean learned from youtube
    completed_todos = db.execute("SELECT * FROM todos WHERE done = ?", True)

    return render_template("index.html", todos=todos, completed_todos=completed_todos)


@app.route("/addtask", methods=["POST"])
@login_required
def addtask():
    todo = request.form['todo']
    user_id = session["user_id"]
    db.execute("INSERT INTO todos (user_id, todo, done) VALUES (?, ?, ?)", user_id, todo, False) 
    return redirect("/")

@app.route("/edit/<int:id>", methods=["GET", "POST"])
@login_required
def edit(id):
    if request.method == "POST":
        new_todo = request.form['todo']
        if new_todo:
            db.execute("UPDATE todos SET todo = ? WHERE id = ?", new_todo, id)
        return redirect("/")
    else:
        todo = db.execute("SELECT * FROM todos WHERE id = ?", id)
        return render_template("edit.html", todo=todo[0])


@app.route("/delete/<int:id>")
@login_required
def delete(id):
    db.execute("DELETE FROM todos WHERE id = ?", id)
    return redirect("/")
# took help from google for this route <int:id>
@app.route("/complete/<int:id>")    

@login_required
def complete(id):
    db.execute("UPDATE todos SET done = 1 WHERE id = ?", id)
    return redirect("/")


@app.route("/login", methods=["GET", "POST"])
def login():
    """Log user in"""

    
    session.clear()

    
    if request.method == "POST":
        
        if not request.form.get("email"):
            flash("Must provide email")
            return redirect("/login")
            

        
        elif not request.form.get("password"):
            return flash("Must provide password")
            return redirect("/login")

        
        rows = db.execute(
            "SELECT * FROM users WHERE email = ?", request.form.get("email")
        )

       
        if len(rows) != 1 or not check_password_hash(
            rows[0]["hash"], request.form.get("password")
        ):
            flash("Must provide email")
            return redirect("/login")

        
        session["user_id"] = rows[0]["id"]

        
        return redirect("/")

    else:
        return render_template("login.html")

@app.route("/logout")
def logout():
    """Log user out"""

    # Forget any user_id
    session.clear()

    # Redirect user to login form
    return redirect("/")
    



@app.route("/register", methods=["GET", "POST"])
def register():
    """Register user"""
    if request.method == "GET":
        return render_template("register.html")
    else:
        email = request.form.get("email")
        password = request.form.get("password")
        confirmation = request.form.get("confirmation")

        if not email:
            flash("Must provide email")
            return redirect("/register")
        elif not password:
            flash("Must provide password")
            return redirect("/register")
        elif not confirmation:
            flash("Please confirm password")
            return redirect("/register")
        elif password != confirmation:
            flash("Passwords do not match")
            return redirect("/register")
        
        

        hash = generate_password_hash(password)

        try:
            new_user = db.execute("INSERT INTO users (email, hash) VALUES (?,?)", email, hash)
        except:
            flash("Must provide email")
            return redirect("/register")

        session["user_id"] = new_user
        return redirect("/")

    

    


if __name__ == '__main__': 
    app.run(debug=True)
        
